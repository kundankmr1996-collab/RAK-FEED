
## मोबाइल से APK बनाने का वैकल्पिक तरीका (GitHub Actions)
इस ZIP में `.github/workflows/android-apk.yml` build workflow शामिल है।
1. GitHub पर account बनाकर नया **public या private repository** बनाएं (उदा. `rak-feed-android`)।
2. ZIP को फोन में extract करें। GitHub की वेबसाइट को Chrome में Desktop site पर खोलें और repository में **Add file → Upload files** से extracted project की सभी फाइलें/फोल्डर अपलोड करके Commit changes करें। `.github` hidden folder upload में न दिखे तो उसे अलग से GitHub पर बनाकर workflow file जोड़ना होगा।
3. Repository में **Actions** टैब खोलें और **Build RAK FEED APK → Run workflow** चलाएं।
4. Build सफल होने पर उसी workflow run के नीचे **Artifacts** में `RAK-FEED-debug-APK` डाउनलोड करें। ZIP extract करके `app-debug.apk` फोन में खोलें और install करें। Android पूछे तो केवल इसी build की APK install करने के लिए browser/files app को permission दें।
5. यह debug APK test के लिए है; Play Store release ke liye signed release build, privacy/security review aur backend setup alag se chahiye.

यदि GitHub पर `.github` folder upload करना कठिन हो, तो मदद लेकर workflow file अलग से जोड़ें। APK build सफल होने की गारंटी नहीं; Actions logs में error आए तो उसे ठीक करना होगा।
