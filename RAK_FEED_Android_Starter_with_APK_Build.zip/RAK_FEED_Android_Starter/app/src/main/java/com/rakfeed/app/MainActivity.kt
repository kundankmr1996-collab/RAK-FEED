package com.rakfeed.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val DarkGreen = Color(0xFF124C35)
private val Gold = Color(0xFFD4AF37)
private val Cream = Color(0xFFF7F6F0)

data class FeedProduct(
    val name: String,
    val priceRupees: Int,
    val packSizeKg: Int = 50
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RakFeedStarterApp() }
    }
}

@Composable
fun RakFeedStarterApp() {
    var hindi by remember { mutableStateOf(true) }
    var showProducts by remember { mutableStateOf(false) }

    val products = remember {
        listOf(
            FeedProduct("PRE STARTER", 3575),
            FeedProduct("STARTER", 3315),
            FeedProduct("FINISHER", 3270),
            FeedProduct("BC", 5000),
            FeedProduct("GROWER", 1250),
            FeedProduct("SONALI", 1650),
            FeedProduct("LAYER", 1250)
        )
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = DarkGreen,
            secondary = Gold,
            background = Cream,
            surface = Color.White
        )
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Cream
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            "RAK FEED",
                            color = DarkGreen,
                            fontSize = 28.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            "RAK AGRO PRODUCTS PVT. LTD.",
                            color = Color.DarkGray,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                    Button(
                        onClick = { hindi = !hindi },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Gold,
                            contentColor = DarkGreen
                        )
                    ) {
                        Text(if (hindi) "हिंदी" else "English")
                    }
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkGreen)
                ) {
                    Column(Modifier.padding(18.dp)) {
                        Text(
                            if (hindi) "स्वागत है" else "Welcome",
                            color = Gold,
                            fontSize = 14.sp
                        )
                        Spacer(Modifier.height(5.dp))
                        Text(
                            if (hindi) "पोल्ट्री फीड ऑर्डर और प्रबंधन" else "Poultry Feed Ordering & Management",
                            color = Color.White,
                            fontSize = 19.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            if (hindi) "Industrial Area, Hajipur, Vaishali, Bihar" else "Industrial Area, Hajipur, Vaishali, Bihar",
                            color = Color.White.copy(alpha = 0.85f),
                            fontSize = 12.sp
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        modifier = Modifier.weight(1f),
                        onClick = { showProducts = !showProducts },
                        colors = ButtonDefaults.buttonColors(containerColor = DarkGreen)
                    ) {
                        Text(if (showProducts) {
                            if (hindi) "डैशबोर्ड" else "Dashboard"
                        } else {
                            if (hindi) "प्रोडक्ट देखें" else "View Products"
                        })
                    }
                    Button(
                        modifier = Modifier.weight(1f),
                        onClick = { },
                        enabled = false,
                        colors = ButtonDefaults.buttonColors(
                            disabledContainerColor = Gold.copy(alpha = 0.45f),
                            disabledContentColor = DarkGreen
                        )
                    ) {
                        Text(if (hindi) "लॉगिन (जल्द)" else "Login (Next)")
                    }
                }

                if (showProducts) {
                    Text(
                        if (hindi) "50 KG बैग के उत्पाद मूल्य" else "Product Prices — 50 KG Bags",
                        color = DarkGreen,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    products.forEach { product ->
                        ProductPriceCard(product = product)
                    }
                } else {
                    Text(
                        if (hindi) "ऐप मॉड्यूल" else "App Modules",
                        color = DarkGreen,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    ModuleCard(
                        title = if (hindi) "ऑर्डर और डिलीवरी" else "Orders & Delivery",
                        detail = if (hindi) "कंपनी वाहन या ग्राहक पिकअप" else "Company vehicle or customer pickup"
                    )
                    ModuleCard(
                        title = if (hindi) "स्टॉक और लेजर" else "Stock & Ledgers",
                        detail = if (hindi) "स्टॉक हिस्ट्री, उधार, भुगतान और बैलेंस" else "Stock history, credit, payments and balances"
                    )
                    ModuleCard(
                        title = if (hindi) "बिलिंग और रिपोर्ट" else "Billing & Reports",
                        detail = if (hindi) "GST / बिना GST बिल और बिक्री रिपोर्ट" else "GST / non-GST invoices and sales reports"
                    )
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF4D6)),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Text(
                            if (hindi) "डेवलपमेंट स्थिति" else "Development Status",
                            color = DarkGreen,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            if (hindi)
                                "यह शुरुआती Android UI प्रोजेक्ट है। OTP, डेटाबेस, ऑनलाइन ऑर्डर, अकाउंटिंग और PDF बिल अभी जुड़े नहीं हैं।"
                            else
                                "This is an initial Android UI starter. OTP, database, online orders, accounting and PDF invoices are not connected yet.",
                            color = Color(0xFF4E4633),
                            fontSize = 12.sp
                        )
                    }
                }

                Text(
                    if (hindi) "संपर्क: 9006545073" else "Contact: 9006545073",
                    color = Color.Gray,
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
private fun ProductPriceCard(product: FeedProduct) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 15.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(product.name, color = DarkGreen, fontWeight = FontWeight.Bold)
                Text("${product.packSizeKg} KG bag", color = Color.Gray, fontSize = 11.sp)
            }
            Text(
                "₹${product.priceRupees}",
                color = DarkGreen,
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp
            )
        }
    }
}

@Composable
private fun ModuleCard(title: String, detail: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(Modifier.padding(15.dp)) {
            Text(title, color = DarkGreen, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(detail, color = Color.Gray, fontSize = 12.sp)
        }
    }
}
