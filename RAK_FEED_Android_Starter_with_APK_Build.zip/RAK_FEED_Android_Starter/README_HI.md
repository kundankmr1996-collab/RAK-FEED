# RAK FEED — Android Starter

यह Android Studio के लिए शुरुआती source project है। इसमें Dark Green + Gold थीम,
Hindi/English toggle, कंपनी का नाम और दिए गए सात 50 KG उत्पादों के मूल्य रखे गए हैं।

## चलाने का तरीका
1. ZIP को extract करें।
2. Android Studio में `RAK_FEED_Android_Starter` folder खोलें।
3. Gradle sync पूरा होने दें।
4. Android emulator या USB debugging वाले फोन पर Run दबाएँ।

## अभी क्या काम करता है
- शुरुआती Home UI
- Hindi / English UI toggle
- Dashboard और product-price सूची के बीच बदलाव
- दिए गए उत्पादों और कीमतों का प्रदर्शन

## अभी क्या जुड़ा नहीं है
यह APK नहीं है और production-ready ऐप नहीं है। OTP login, Firebase/backend,
customer/dealer accounts, Owner/employee permissions, live orders, stock ledger,
payments, GST/non-GST PDF billing और reports अभी implement/connect नहीं किए गए हैं।
Login बटन जानबूझकर disabled है ताकि नकली login का दावा न हो।

## अगला implementation क्रम
1. Backend और database schema तय करना।
2. Firebase Phone OTP और सुरक्षित user-role authorization जोड़ना।
3. Products, customers/dealers और orders के APIs बनाना।
4. Stock movements और customer/dealer ledgers को transaction-safe बनाना।
5. GST settings (GSTIN, HSN और tax rates मिलने के बाद), non-GST invoices और PDF export।
6. Testing, signed APK और release प्रक्रिया।

## अभी लंबित व्यावसायिक जानकारी
- GSTIN, HSN और लागू tax rates
- Delivery charge तय करने का नियम / per-order entry
- Firebase project और backend hosting credentials

किसी भी live ग्राहक का डेटा या असली OTP इस demo project में शामिल नहीं है।
